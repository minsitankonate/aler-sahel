<?php
/*
	defined all constants;
*/
if( !defined('ABSPATH')) { die( 'direct browsing can not possible');}
if( !defined('POST_GRID_CAROUSEL_TEXTDOMAIN')) { define('POST_GRID_CAROUSEL_TEXTDOMAIN','post-grid-and-carousel-ultimate');}
if( !defined('ADL_POST_TYPE')) { define('ADL_POST_TYPE','post-grid-carousel');}
if( !defined('ADL_SHORT_CODE_POST_TYPE')) { define('ADL_SHORT_CODE_POST_TYPE','adl-shortcode');}
