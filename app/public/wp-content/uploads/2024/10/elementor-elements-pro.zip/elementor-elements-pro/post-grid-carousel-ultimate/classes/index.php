<?php
//silence is the gold.