<?php
// it protects if the folder is access directly.
